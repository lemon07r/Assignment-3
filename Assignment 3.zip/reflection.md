## WEB322 - Assignment 3 Reflection 
##### Lamim Rashid - 017156142

### Setting up tailwind
Fairly straight foward, this is something I have previous experience with too. I use the retro theme here since I feel it best matches the content that will populate our website. 

### Making the views
I use semantic html tags to help structure my html pages, then start to assemble parts of my view with daisyui components. 
We make two different drop down views, one for mobile, and one for desktop views, based on the viewport.

### About Me page
Wasn't sure what pictures to use, so I used some spiderman ones since I like spiderman. 

### Tailwind and daisyui
Strugged a bit with some ui stuff, trying to do things the tailwind way instead of the daisyui way, like using psuedo classes for things like active button the tailwind way, when daisyui already had a class for this. Eventually figured it out. 

### Hosting on Cyclic
Got an error trying to open private repos on cyclic, even using different browser (both chrome and firefox). Had to switch the repository to public unfortunately. 